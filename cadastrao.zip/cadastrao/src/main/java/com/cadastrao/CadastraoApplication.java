package com.cadastrao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastraoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastraoApplication.class, args);
	}

}
