package com.cadastrao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastraoApplicationTests {

	@Test
	void contextLoads() {
	}

}
